/*
Navicat MySQL Data Transfer

Source Server         : TEST
Source Server Version : 80016
Source Host           : localhost:3306
Source Database       : test

Target Server Type    : MYSQL
Target Server Version : 80016
File Encoding         : 65001

Date: 2020-07-10 09:42:48
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for goods
-- ----------------------------
DROP TABLE IF EXISTS `goods`;
CREATE TABLE `goods` (
  `goodsId` int(10) NOT NULL AUTO_INCREMENT,
  `goodsName` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `goodsPrice` double(10,2) NOT NULL,
  PRIMARY KEY (`goodsId`)
) ENGINE=InnoDB AUTO_INCREMENT=20200727 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of goods
-- ----------------------------
INSERT INTO `goods` VALUES ('20200723', '我的书', '100.00');
INSERT INTO `goods` VALUES ('20200724', '《孤独旅行家》', '29.00');
INSERT INTO `goods` VALUES ('20200725', '《快乐星球》', '3.00');
INSERT INTO `goods` VALUES ('20200726', '笔记本电脑', '5499.00');
