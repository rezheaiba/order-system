package com.po;

import java.util.Date;

public class Orders {
	private String name;
	private int phoneNumber;
	private String myGoods;
	private String address;
	private int ordernumber;
	private Date date;

	
	public Orders() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	public Orders(String name, int phoneNumber, String myGoods,String address, int ordernumber, Date date) {
		super();
		this.name = name;
		this.phoneNumber = phoneNumber;
		this.myGoods = myGoods;
		this.address = address;
		this.ordernumber = ordernumber;
		this.date = date;
	}

	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhonenumber(int phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	
	public String getMyGoods() {
		return myGoods;
	}


	public void setMyGoods(String myGoods) {
		this.myGoods = myGoods;
	}


	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public int getOrdernumber() {
		return ordernumber;
	}

	public void setOrdernumber(int ordernumber) {
		this.ordernumber = ordernumber;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

}
