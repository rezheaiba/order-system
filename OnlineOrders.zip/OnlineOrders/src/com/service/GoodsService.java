package com.service;

import java.util.List;

import com.po.Goods;

public interface GoodsService {
	public List<Goods> selectAllGoods();
	public void deleteGoods(int id);
	public void insertGoods(Goods goods);
	public void updateGoods(Goods goods);
}
