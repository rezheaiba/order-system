package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.GoodsDao;
import com.po.Goods;

@Service("goodsService")
public class GoodsServiceImpl implements GoodsService {

	@Autowired
	private GoodsDao goodsDao;

	@Override
	public List<Goods> selectAllGoods() {
		// TODO Auto-generated method stub
		return goodsDao.selectAllGoods();
	}

	@Override
	public void deleteGoods(int id) {
		// TODO Auto-generated method stub
		goodsDao.deleteGoods(id);
	}

	@Override
	public void insertGoods(Goods goods) {
		// TODO Auto-generated method stub
		goodsDao.insertGoods(goods);
	}

	@Override
	public void updateGoods(Goods goods) {
		// TODO Auto-generated method stub
		goodsDao.updateGoods(goods);
	}

}
