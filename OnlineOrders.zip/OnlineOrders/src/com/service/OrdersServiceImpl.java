package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.OrdersDao;
import com.po.Orders;

@Service("ordersService")
public class OrdersServiceImpl implements OrdersService {
	@Autowired
	private OrdersDao ordersDao;

	@Override
	public void insertOrders(Orders orders) {
		// TODO Auto-generated method stub
		ordersDao.insertOrders(orders);
	}

	@Override
	public List<Orders> selectAllOrders() {
		// TODO Auto-generated method stub
		return ordersDao.selectAllOrders();
	}

}
