package com.service;

import java.util.List;

import com.po.Orders;

public interface OrdersService {
	public void insertOrders(Orders orders);
	public List<Orders> selectAllOrders();
}
