package com.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import com.po.Orders;
@Mapper
@Repository("ordersDao")
public interface OrdersDao {
	public void insertOrders(Orders orders);
	public List<Orders> selectAllOrders();
}
