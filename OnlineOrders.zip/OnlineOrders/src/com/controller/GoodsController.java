package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.po.Goods;
import com.service.GoodsService;

@Controller("goodsController")
@RequestMapping("/goods")
public class GoodsController {
	@Autowired
	private GoodsService goodsService;
	//����Ա��¼
	@RequestMapping("/adminlogin")
	public String AdminLogin(Model model) {
		return "manageAllGoods";
	}
	// �˿͵�¼
	@RequestMapping("/login")
	public String Login(String account, String password, Model model) {
		if ("jyq".equals(account) &&  "123456".equals(password)||"rezheaiba".equals(account) && "123456".equals(password)) {
			model.addAttribute("account", account);
			model.addAttribute("password", password);
			return "redirect:/goods/selectAllGoods";
		}else {
			model.addAttribute("massage", "�û�����������������������������Ʒ��");
			return "selectAllGoods";
		}
	}

	// ��ʾ������Ʒ���˿���
	@RequestMapping("/selectAllGoods")
	public String selectAllGoods(Model model) {
		List<Goods> allGoods = goodsService.selectAllGoods();
		model.addAttribute("allGoods", allGoods);
		return "selectAllGoods";
	}
	
	//����������Ʒ������Ա��
	@RequestMapping("/manageAllGoods")
	public String manageAllGoods(Model model) {
		List<Goods> allGoods = goodsService.selectAllGoods();
		model.addAttribute("allGoods", allGoods);
		return "manageAllGoods";
		}
	
	//����Աɾ����Ʒ
	@RequestMapping("/deleteGoods")
	public String deleteGoods(int goodsId) {
		goodsService.deleteGoods(goodsId);
		return "redirect:/goods/manageAllGoods";
		}
	
	//����Ա������Ʒ��Ϣ
	@RequestMapping("/insertGoods")
	public String insertGoods(String goodsname,String goodsprice) {
		Goods goods = new Goods(goodsname,Double.parseDouble(goodsprice));
		goodsService.insertGoods(goods);
		return "redirect:/goods/manageAllGoods";
	}
	
	//����Ա�޸���Ʒ
		@RequestMapping("/updateGoods")
		public String updateGoods(int goodsId) {
			Goods goods = new Goods("�ҵ���",100);
			goods.setGoodsId(goodsId);
			goodsService.updateGoods(goods);
			return "redirect:/goods/manageAllGoods";
			}
}
