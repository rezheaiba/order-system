package com.controller;


import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.po.Orders;
import com.service.OrdersService;

@Controller("ordersController")
@RequestMapping("/orders")
public class OrdersController {
	@Autowired
	private OrdersService ordersService;
	
	//��ת������ҳ�棬ȥ��д������Ϣ
	@RequestMapping("/buyGoods")
	public String buyGoods(String gname, Model model) {
		model.addAttribute("gname", gname);
		return "BuyGoods";
	}
	
	@RequestMapping("/selectAllOrders")
	public String selectAllOrders(Model model) {
		List<Orders> orders =  ordersService.selectAllOrders();
		model.addAttribute("myorders", orders);
		return "myOrders";
	}
	//��������
	@RequestMapping("/myOrders")
	public String myOrders(String gname,String inputName,String inputPhoneNumber,String inputAddress) {
		int max=10000,min=1;
		int ordernumber = (int) (Math.random()*(max-min)+min); 
		Orders orders = new Orders(inputName,Integer.parseInt(inputPhoneNumber),gname,inputAddress,ordernumber,new Date());
		ordersService.insertOrders(orders);
		return "redirect:/orders/selectAllOrders";
	}
}
